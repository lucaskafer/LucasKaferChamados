package com.example.lucaskaferchamados.config;

public class Tabelas {

    public static final String TB_USUARIOS = "usuarios";
    public static final String TB_OS = "ordemServico";
    public static final String TB_SERVICOS = "servicos";
}
